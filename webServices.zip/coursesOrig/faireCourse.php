<?php
include("commun.php");
//requete sql
$noListeEnCours=0;
$familleId=1;
$magasinId=1
if(isset($_GET['action']))
{
	$action=$_GET['action'];
	$tabNoProduitdansCourses=$_GET['tabNoProduit'];
	Switch($action)
{
	case "Caddy":
	foreach($tabNoProduitdansCourses as $noProduit)
	{
		$sql="update contenuListe set dansCaddy=1 where produitId=$noProduit and listeId=$noListeEnCours";
		$res=mysql_query($sql);
	}

break;
	case "Annuler":break;

	case "Reporter":
		sresNumListe=mysql_query("select MAX(listeId) as max from liste where familleid=$familleId ");
		$line=mysql_fetch_array($resNumListe);
		$numListe=$line[max];
		if ($numListe==noListeEnCours)
			{
				$resmaxListe="select MAX(listeId) as max from liste";
				$line=mysql_fetch_array($resmaxListe);
				$num=$line[max]+1;
				$resAddListe=mysql_query("insert into liste(listeId,familleId,encours,dateCreation,magasinId) values ($num,$familleId,0,current_date,$magasinID);"
				foreach($tabNoProduitdansCourses as $noProduit)
				{
					$sql="update contenuListe set listeId=$resNumListe 	where produitId=$noProduit and listeId=$noListeEnCours";
					$res=mysql_query($sql);
				}
			}
			else
			{

				foreach($tabNoProduitdansCourses as $noProduit)
				{
					$sql="update contenuListe set listeId=$resNumListe 	where produitId=$noProduit and listeId=$noListeEnCours";
					$res=mysql_query($sql);
				}
			}
break;
}
}

//son numéro, son libellé, la quantité à acheter, le numéro du rayon dans lequel il est ainsi que le libellé de ce rayon.

$sql = "select produit.produitId as produitId,produitLib,listeQte,rayon.rayonId as rayonId ,rayonLib from contenuListe natural join produit natural join rayon natural join liste where enCours=true and listeId =$noListeEnCours and dansCaddy=0"; 
//todo récupérer le num de la liste correspondant à la famille du membre loggé.
//</todo>
//execution
$result = mysql_query($sql);
//le tableau
$monTableau = array();
if(mysql_num_rows($result))//s'il y a un resultat
{
	while($ligne=mysql_fetch_assoc($result))
	{
		$monTableau['coursesAFaire'][]=$ligne;
	}
}
echo json_encode($monTableau); 
?>