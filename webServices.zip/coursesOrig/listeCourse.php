<?php
include("commun.php");
if(isset($_GET['action']))
{
	$action=$_GET['action'];
	$noProduit=$_GET['produitId'];
	$qte=$_GET['qte'];
	$res=mysql_query("select count(*) as nb from contenuListe where produitId=".$noProduit." and listeId=0;");
	$line=mysql_fetch_array($res);
	$nb=$line["nb"];
	if($action=="ajout")
	{
		if($nb==0)
		{
			$sql = "insert into contenuListe(listeId,produitId,listeQte,dansCaddy) values(0,$noProduit,$qte,0)"; 
			$result = mysql_query($sql);
		}
		else
		{
			$result=mysql_query("update contenuListe set listeQte=listeQte+".$qte." ,dansCaddy=0 where produitId=".$noProduit." and listeId=0;");
		}
	}
}
$json = array();
$sql2="select contenuListe.produitId as produitId ,produitLib,listeQte from contenuListe inner join produit on produit.produitId=contenuListe.produitId";
$result2=mysql_query($sql2);
while($row=mysql_fetch_assoc($result2))
{
	$json['listeDeCourse'][]=$row;
}
echo json_encode($json);
?>