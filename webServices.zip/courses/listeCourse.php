<?php
include("commun.php");
if(isset($_GET['action']))
{
	$action=$_GET['action'];
	$noProduit=$_GET['produitId'];
	$qte=$_GET['qte'];
	$res=mysql_query("select count(*) as nb from liste where produitId=".$noProduit." and listeId=0;");
	$line=mysql_fetch_array($res);
	$nb=$line["nb"];
	if($action=="ajout")
	{
		if($nb==0)
		{
			$sql = "insert into liste(listeId,produitId,listeQte) values(0,$noProduit,$qte)"; 
			$result = mysql_query($sql);
		}
		else
		{
			$result=mysql_query("update liste set listeQte=listeQte+".$qte." where produitId=".$noProduit." and listeId=0;");
		}
	}
}
$json = array();
$sql2="select liste.produitId as produitId ,produitLib,listeQte from liste inner join produit on produit.produitId=liste.produitId";
$result2=mysql_query($sql2);
while($row=mysql_fetch_assoc($result2))
{
	$json['listeDeCourse'][]=$row;
}
echo json_encode($json);
?>