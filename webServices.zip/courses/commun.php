<?php
$host="mysql.hostinger.fr"; //replace with database hostname 
$username="u683437950_userl"; //replace with database username 
$password="lcpasswd"; //replace with database password 
$db_name="u683437950_dblis"; //replace with database name
$con=mysql_connect("$host", "$username","$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");
?>